package com.example.storybook

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface

object SettingsManager {

    private const val PREFS_NAME = "settings_prefs"
    private const val KEY_FONT_INDEX = "font_index"
    private const val KEY_COLOR_INDEX = "color_index"

    // نام فونت‌ها (فونت‌های داخلی اندروید که بدون فایل اضافه کار می‌کنند)
    // برای افزودن فونت فارسی اختصاصی (مثلا وزیر یا ایران‌سنس)،
    // فایل .ttf را در res/font قرار دهید و در اینجا با ResourcesCompat.getFont ارجاع دهید.
    val fontNames = listOf("پیش‌فرض", "سریف", "بدون سریف", "مونو‌اسپیس", "غیررسمی")

    private val typefaces = listOf(
        Typeface.DEFAULT,
        Typeface.SERIF,
        Typeface.SANS_SERIF,
        Typeface.MONOSPACE,
        Typeface.create("cursive", Typeface.NORMAL)
    )

    val colorNames = listOf("مشکی", "خاکستری تیره", "قهوه‌ای", "سرمه‌ای", "سبز تیره")

    private val colorValues = listOf(
        Color.parseColor("#000000"),
        Color.parseColor("#3A3A3A"),
        Color.parseColor("#4A3B2A"),
        Color.parseColor("#1B2A4A"),
        Color.parseColor("#1F3B2C")
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getFontIndex(context: Context): Int = prefs(context).getInt(KEY_FONT_INDEX, 0)
    fun getColorIndex(context: Context): Int = prefs(context).getInt(KEY_COLOR_INDEX, 0)

    fun getTypeface(context: Context): Typeface = typefaces[getFontIndex(context)]
    fun getTextColor(context: Context): Int = colorValues[getColorIndex(context)]

    fun save(context: Context, fontIndex: Int, colorIndex: Int) {
        prefs(context).edit()
            .putInt(KEY_FONT_INDEX, fontIndex)
            .putInt(KEY_COLOR_INDEX, colorIndex)
            .apply()
    }
}
