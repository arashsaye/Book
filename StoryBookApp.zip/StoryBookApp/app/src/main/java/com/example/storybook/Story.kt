package com.example.storybook

data class Story(
    val id: String,
    val title: String,
    val content: String
)
