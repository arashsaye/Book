package com.example.storybook

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class StoryPagerAdapter(
    activity: FragmentActivity,
    private val pages: List<String>
) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int = pages.size

    override fun createFragment(position: Int): Fragment {
        return StoryPageFragment.newInstance(pages[position])
    }
}
