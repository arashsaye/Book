package com.example.storybook

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.storybook.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var selectedFontIndex = 0
    private var selectedColorIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        selectedFontIndex = SettingsManager.getFontIndex(this)
        selectedColorIndex = SettingsManager.getColorIndex(this)

        val fontAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.fontNames)
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFont.adapter = fontAdapter
        binding.spinnerFont.setSelection(selectedFontIndex)

        val colorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.colorNames)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerColor.adapter = colorAdapter
        binding.spinnerColor.setSelection(selectedColorIndex)

        updatePreview()

        binding.spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedFontIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedColorIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnSave.setOnClickListener {
            SettingsManager.save(this, selectedFontIndex, selectedColorIndex)
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePreview() {
        val typeface = when (selectedFontIndex) {
            1 -> android.graphics.Typeface.SERIF
            2 -> android.graphics.Typeface.SANS_SERIF
            3 -> android.graphics.Typeface.MONOSPACE
            4 -> android.graphics.Typeface.create("cursive", android.graphics.Typeface.NORMAL)
            else -> android.graphics.Typeface.DEFAULT
        }
        val colorHex = when (selectedColorIndex) {
            1 -> "#3A3A3A"
            2 -> "#4A3B2A"
            3 -> "#1B2A4A"
            4 -> "#1F3B2C"
            else -> "#000000"
        }
        binding.tvPreview.typeface = typeface
        binding.tvPreview.setTextColor(android.graphics.Color.parseColor(colorHex))
    }
}
