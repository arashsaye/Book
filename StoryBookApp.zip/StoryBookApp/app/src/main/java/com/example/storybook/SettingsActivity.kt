package com.example.storybook

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.storybook.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var selectedFontIndex = 0
    private var selectedColorIndex = 0
    private var selectedTextSizeIndex = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        selectedFontIndex = SettingsManager.getFontIndex(this)
        selectedColorIndex = SettingsManager.getColorIndex(this)
        selectedTextSizeIndex = SettingsManager.getTextSizeIndex(this)

        // تم تاریک
        binding.switchDarkMode.isChecked = SettingsManager.isDarkMode(this)
        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            SettingsManager.setDarkMode(this, isChecked)
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
            recreate()
        }

        val fontAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.fontNames)
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFont.adapter = fontAdapter
        binding.spinnerFont.setSelection(selectedFontIndex)

        val textSizeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.textSizeNames)
        textSizeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTextSize.adapter = textSizeAdapter
        binding.spinnerTextSize.setSelection(selectedTextSizeIndex)

        val colorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.colorNames)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerColor.adapter = colorAdapter
        binding.spinnerColor.setSelection(selectedColorIndex)

        updatePreview()

        binding.spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedFontIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerTextSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedTextSizeIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedColorIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnSave.setOnClickListener {
            SettingsManager.save(this, selectedFontIndex, selectedColorIndex, selectedTextSizeIndex)
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePreview() {
        val typeface = when (selectedFontIndex) {
            1 -> android.graphics.Typeface.SERIF
            2 -> android.graphics.Typeface.SANS_SERIF
            3 -> android.graphics.Typeface.MONOSPACE
            4 -> android.graphics.Typeface.create("cursive", android.graphics.Typeface.NORMAL)
            else -> android.graphics.Typeface.DEFAULT
        }
        val colorHex = when (selectedColorIndex) {
            1 -> "#8B1E1E"
            2 -> "#173E7A"
            3 -> "#1F6B33"
            4 -> "#5A1E7A"
            else -> "#000000"
        }
        val textSizeSp = when (selectedTextSizeIndex) {
            0 -> 14f
            1 -> 16f
            3 -> 21f
            4 -> 25f
            else -> 18f
        }
        binding.tvPreview.typeface = typeface
        binding.tvPreview.setTextColor(android.graphics.Color.parseColor(colorHex))
        binding.tvPreview.textSize = textSizeSp
    }
}
