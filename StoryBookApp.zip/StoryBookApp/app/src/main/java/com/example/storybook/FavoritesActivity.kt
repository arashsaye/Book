package com.example.storybook

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storybook.databinding.ActivityFavoritesBinding

class FavoritesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritesBinding
    private lateinit var adapter: StoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = StoryAdapter(emptyList()) { story ->
            val intent = Intent(this, StoryReaderActivity::class.java)
            intent.putExtra(StoryReaderActivity.EXTRA_STORY_ID, story.id)
            startActivity(intent)
        }
        binding.recyclerView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        // هر بار که صفحه دوباره نمایش داده شود، لیست علاقه‌مندی‌ها به‌روزرسانی می‌شود
        val favorites = FavoritesManager.getFavoriteStories(this)
        adapter.updateData(favorites)
        binding.tvEmpty.visibility = if (favorites.isEmpty()) View.VISIBLE else View.GONE
    }
}
