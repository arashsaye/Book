package com.example.storybook

import android.content.Context

object FavoritesManager {

    private const val PREFS_NAME = "favorites_prefs"
    private const val KEY_FAVORITES = "favorite_ids"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isFavorite(context: Context, storyId: String): Boolean {
        return getFavoriteIds(context).contains(storyId)
    }

    fun toggleFavorite(context: Context, storyId: String): Boolean {
        val current = getFavoriteIds(context).toMutableSet()
        val nowFavorite: Boolean
        if (current.contains(storyId)) {
            current.remove(storyId)
            nowFavorite = false
        } else {
            current.add(storyId)
            nowFavorite = true
        }
        prefs(context).edit().putStringSet(KEY_FAVORITES, current).apply()
        return nowFavorite
    }

    fun getFavoriteIds(context: Context): Set<String> {
        return prefs(context).getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
    }

    fun getFavoriteStories(context: Context): List<Story> {
        val ids = getFavoriteIds(context)
        return StoryRepository.getAllStories(context).filter { ids.contains(it.id) }
    }
}
