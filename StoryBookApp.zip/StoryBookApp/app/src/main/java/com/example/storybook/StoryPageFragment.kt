package com.example.storybook

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.storybook.databinding.FragmentStoryPageBinding

class StoryPageFragment : Fragment() {

    companion object {
        private const val ARG_TEXT = "page_text"
        private const val ARG_COVER = "cover_image_name"
        private const val ARG_SHOW_COVER = "show_cover"

        fun newInstance(pageText: String, coverImageName: String?, showCover: Boolean): StoryPageFragment {
            val fragment = StoryPageFragment()
            val args = Bundle()
            args.putString(ARG_TEXT, pageText)
            args.putString(ARG_COVER, coverImageName)
            args.putBoolean(ARG_SHOW_COVER, showCover)
            fragment.arguments = args
            return fragment
        }
    }

    private var _binding: FragmentStoryPageBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStoryPageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val text = arguments?.getString(ARG_TEXT).orEmpty()
        val coverName = arguments?.getString(ARG_COVER)
        val showCover = arguments?.getBoolean(ARG_SHOW_COVER) ?: false

        binding.tvPageContent.text = text
        binding.tvPageContent.typeface = SettingsManager.getTypeface(requireContext())
        binding.tvPageContent.setTextColor(SettingsManager.getTextColor(requireContext()))

        if (showCover && !coverName.isNullOrBlank()) {
            val resId = resources.getIdentifier(coverName, "drawable", requireContext().packageName)
            if (resId != 0) {
                binding.ivCover.setImageResource(resId)
                binding.ivCover.visibility = View.VISIBLE
            } else {
                binding.ivCover.visibility = View.GONE
            }
        } else {
            binding.ivCover.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

