package com.example.storybook

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.storybook.databinding.FragmentStoryPageBinding

class StoryPageFragment : Fragment() {

    companion object {
        private const val ARG_TEXT = "page_text"

        fun newInstance(pageText: String): StoryPageFragment {
            val fragment = StoryPageFragment()
            val args = Bundle()
            args.putString(ARG_TEXT, pageText)
            fragment.arguments = args
            return fragment
        }
    }

    private var _binding: FragmentStoryPageBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStoryPageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val text = arguments?.getString(ARG_TEXT).orEmpty()
        binding.tvPageContent.text = text
        binding.tvPageContent.typeface = SettingsManager.getTypeface(requireContext())
        binding.tvPageContent.setTextColor(SettingsManager.getTextColor(requireContext()))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
