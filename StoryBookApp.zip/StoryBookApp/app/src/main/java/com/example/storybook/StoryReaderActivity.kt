package com.example.storybook

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.storybook.databinding.ActivityStoryReaderBinding

class StoryReaderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STORY_ID = "extra_story_id"
    }

    private lateinit var binding: ActivityStoryReaderBinding
    private lateinit var story: Story
    private lateinit var pages: List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val storyId = intent.getStringExtra(EXTRA_STORY_ID)
        val loadedStory = storyId?.let { StoryRepository.getStoryById(this, it) }

        if (loadedStory == null) {
            finish()
            return
        }
        story = loadedStory
        pages = PagingUtil.splitIntoPages(story.content)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.tvToolbarTitle.text = story.title

        binding.viewPager.adapter = StoryPagerAdapter(this, pages)

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageIndicator(position)
            }
        })
        updatePageIndicator(0)
        updateFavoriteIcon()

        binding.btnPrevPage.setOnClickListener {
            if (binding.viewPager.currentItem > 0) {
                binding.viewPager.currentItem -= 1
            }
        }
        binding.btnNextPage.setOnClickListener {
            if (binding.viewPager.currentItem < pages.size - 1) {
                binding.viewPager.currentItem += 1
            }
        }

        binding.btnFavoriteToggle.setOnClickListener {
            FavoritesManager.toggleFavorite(this, story.id)
            updateFavoriteIcon()
            // طبق نیاز پروژه: انتخاب علامت علاقه‌مندی کاربر را به صفحه‌ی علاقه‌مندی‌ها می‌برد
            startActivity(Intent(this, FavoritesActivity::class.java))
        }
    }

    private fun updatePageIndicator(position: Int) {
        binding.tvPageIndicator.text =
            getString(R.string.page_indicator, position + 1, pages.size)
        binding.btnPrevPage.isEnabled = position > 0
        binding.btnNextPage.isEnabled = position < pages.size - 1
    }

    private fun updateFavoriteIcon() {
        val isFav = FavoritesManager.isFavorite(this, story.id)
        binding.btnFavoriteToggle.setImageResource(
            if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
        )
    }
}
