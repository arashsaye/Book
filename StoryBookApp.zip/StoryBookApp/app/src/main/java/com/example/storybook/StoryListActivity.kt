package com.example.storybook

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storybook.databinding.ActivityStoryListBinding

class StoryListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStoryListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val stories = StoryRepository.getAllStories(this)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        val adapter = StoryAdapter(stories) { story ->
            val intent = Intent(this, StoryReaderActivity::class.java)
            intent.putExtra(StoryReaderActivity.EXTRA_STORY_ID, story.id)
            startActivity(intent)
        }
        binding.recyclerView.adapter = adapter

        binding.tvEmpty.visibility = if (stories.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }
}
