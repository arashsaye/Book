package ir.arash.bookstory

import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import androidx.fragment.app.Fragment
import ir.arash.bookstory.databinding.FragmentStoryPageBinding

class StoryPageFragment : Fragment() {

    companion object {
        private const val ARG_TEXT = "page_text"
        private const val ARG_COVER = "cover_image_name"
        private const val ARG_SHOW_COVER = "show_cover"
        private const val ARG_HIGHLIGHT_START = "highlight_start"
        private const val ARG_HIGHLIGHT_END = "highlight_end"

        fun newInstance(
            pageText: String,
            coverImageName: String?,
            showCover: Boolean,
            highlightStart: Int = -1,
            highlightEnd: Int = -1
        ): StoryPageFragment {
            val fragment = StoryPageFragment()
            val args = Bundle()
            args.putString(ARG_TEXT, pageText)
            args.putString(ARG_COVER, coverImageName)
            args.putBoolean(ARG_SHOW_COVER, showCover)
            args.putInt(ARG_HIGHLIGHT_START, highlightStart)
            args.putInt(ARG_HIGHLIGHT_END, highlightEnd)
            fragment.arguments = args
            return fragment
        }
    }

    private var _binding: FragmentStoryPageBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStoryPageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val text = arguments?.getString(ARG_TEXT).orEmpty()
        val coverName = arguments?.getString(ARG_COVER)
        val showCover = arguments?.getBoolean(ARG_SHOW_COVER) ?: false
        val highlightStart = arguments?.getInt(ARG_HIGHLIGHT_START) ?: -1
        val highlightEnd = arguments?.getInt(ARG_HIGHLIGHT_END) ?: -1

        binding.tvPageContent.typeface = SettingsManager.getTypeface(requireContext())
        binding.tvPageContent.setTextColor(SettingsManager.getTextColor(requireContext()))
        binding.tvPageContent.textSize = SettingsManager.getTextSizeSp(requireContext())

        val hasHighlight = highlightStart >= 0 && highlightEnd > highlightStart && highlightEnd <= text.length

        if (hasHighlight) {
            val spannable = SpannableString(text)
            spannable.setSpan(
                BackgroundColorSpan(0x99C9A15A.toInt()),
                highlightStart,
                highlightEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            binding.tvPageContent.text = spannable
            scrollToHighlight(highlightStart)
        } else {
            binding.tvPageContent.text = text
        }

        if (showCover && !coverName.isNullOrBlank()) {
            val resId = resources.getIdentifier(coverName, "drawable", requireContext().packageName)
            if (resId != 0) {
                binding.ivCover.setImageResource(resId)
                binding.ivCover.visibility = View.VISIBLE
            } else {
                binding.ivCover.visibility = View.GONE
            }
        } else {
            binding.ivCover.visibility = View.GONE
        }
    }

    /** بعد از این‌که چیدمان صفحه کامل شد، دقیقاً همان خطی که کلمه‌ی جستجو‌شده در آن است را وسط صفحه می‌آورد. */
    private fun scrollToHighlight(charOffset: Int) {
        binding.tvPageContent.post {
            val binding = _binding ?: return@post
            val layout = binding.tvPageContent.layout ?: return@post
            val line = layout.getLineForOffset(charOffset)
            val lineTop = layout.getLineTop(line)

            // موقعیت TextView را نسبت به ScrollView محاسبه می‌کنیم (چون چند لایه‌ی تودرتو بینشان هست)
            var offsetWithinScroll = 0
            var current: View = binding.tvPageContent
            val scrollView = binding.root as ScrollView
            while (current !== scrollView) {
                offsetWithinScroll += current.top
                current = current.parent as View
            }

            val targetY = (offsetWithinScroll + lineTop - 120).coerceAtLeast(0)
            scrollView.smoothScrollTo(0, targetY)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


