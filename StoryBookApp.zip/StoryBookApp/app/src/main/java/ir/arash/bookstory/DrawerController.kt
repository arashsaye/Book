package ir.arash.bookstory

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout

/**
 * منوی کشویی (همبرگری) که در تمام صفحات برنامه یکسان است.
 *
 * برای عوض کردن آیدی تلگرام نویسنده/برنامه‌نویس، فقط دو مقدار زیر را عوض کنید.
 * فعلاً هر دو به‌صورت پیش‌فرض روی @arash تنظیم شده‌اند.
 */
object DrawerController {

    const val TELEGRAM_AUTHOR_USERNAME = "mojganakbari1358"
    const val TELEGRAM_DEVELOPER_USERNAME = "Arash_a_63"

    /** ردیف‌های داخل منو را به رفتار درست وصل می‌کند. باید در هر Activity یک‌بار در onCreate صدا زده شود. */
    fun setup(activity: AppCompatActivity, drawerLayout: DrawerLayout) {
        drawerLayout.findViewById<View>(R.id.drawerSettings).setOnClickListener {
            drawerLayout.closeDrawers()
            navigateIfNeeded(activity, SettingsActivity::class.java)
        }
        drawerLayout.findViewById<View>(R.id.drawerSearch).setOnClickListener {
            drawerLayout.closeDrawers()
            navigateIfNeeded(activity, SearchActivity::class.java)
        }
        drawerLayout.findViewById<View>(R.id.drawerFavorites).setOnClickListener {
            drawerLayout.closeDrawers()
            navigateIfNeeded(activity, FavoritesActivity::class.java)
        }
        drawerLayout.findViewById<View>(R.id.drawerContactAuthor).setOnClickListener {
            drawerLayout.closeDrawers()
            openTelegram(activity, TELEGRAM_AUTHOR_USERNAME)
        }
        drawerLayout.findViewById<View>(R.id.drawerContactDeveloper).setOnClickListener {
            drawerLayout.closeDrawers()
            openTelegram(activity, TELEGRAM_DEVELOPER_USERNAME)
        }
        drawerLayout.findViewById<View>(R.id.drawerExit).setOnClickListener {
            drawerLayout.closeDrawers()
            confirmExit(activity)
        }
    }

    fun openDrawer(drawerLayout: DrawerLayout) {
        drawerLayout.openDrawer(GravityCompat.START)
    }

    private fun navigateIfNeeded(activity: Activity, target: Class<*>) {
        // اگر همان صفحه بود دوباره بازش نکن
        if (activity.javaClass == target) return
        activity.startActivity(Intent(activity, target))
    }

    private fun openTelegram(activity: Activity, username: String) {
        try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=$username")))
        } catch (e: ActivityNotFoundException) {
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$username")))
        }
    }

    fun confirmExit(activity: Activity) {
        AlertDialog.Builder(activity, R.style.AppAlertDialogTheme)
            .setTitle(R.string.exit_confirm_title)
            .setMessage(R.string.exit_confirm_message)
            .setPositiveButton(R.string.yes) { _, _ -> activity.finishAffinity() }
            .setNegativeButton(R.string.no, null)
            .show()
    }
}
