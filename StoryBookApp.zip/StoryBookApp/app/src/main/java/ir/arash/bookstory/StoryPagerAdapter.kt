package ir.arash.bookstory

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class StoryPagerAdapter(
    activity: FragmentActivity,
    private val pages: List<String>,
    private val coverImageName: String? = null
) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int = pages.size

    override fun createFragment(position: Int): Fragment {
        return StoryPageFragment.newInstance(pages[position], coverImageName, showCover = position == 0)
    }
}

