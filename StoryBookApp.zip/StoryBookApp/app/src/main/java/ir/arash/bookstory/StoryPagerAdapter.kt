package ir.arash.bookstory

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class StoryPagerAdapter(
    activity: FragmentActivity,
    private val pages: List<String>,
    private val coverImageName: String? = null,
    private val highlightPageIndex: Int = -1,
    private val highlightStart: Int = -1,
    private val highlightEnd: Int = -1
) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int = pages.size

    override fun createFragment(position: Int): Fragment {
        val hasHighlight = position == highlightPageIndex && highlightStart in 0..pages[position].length
        return StoryPageFragment.newInstance(
            pageText = pages[position],
            coverImageName = coverImageName,
            showCover = position == 0,
            highlightStart = if (hasHighlight) highlightStart else -1,
            highlightEnd = if (hasHighlight) highlightEnd else -1
        )
    }
}


