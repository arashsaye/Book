package ir.arash.bookstory

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import ir.arash.bookstory.databinding.ActivitySearchBinding

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private lateinit var adapter: SearchResultAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolbar.inflateMenu(R.menu.menu_drawer_toggle)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_open_drawer) {
                DrawerController.openDrawer(binding.drawerLayout)
                true
            } else false
        }
        DrawerController.setup(this, binding.drawerLayout)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = SearchResultAdapter(emptyList(), "") { match ->
            val intent = Intent(this, StoryReaderActivity::class.java)
            intent.putExtra(StoryReaderActivity.EXTRA_STORY_ID, match.storyId)
            intent.putExtra(StoryReaderActivity.EXTRA_SEARCH_QUERY, binding.etSearch.text?.toString().orEmpty())
            intent.putExtra(StoryReaderActivity.EXTRA_MATCH_CHAR_INDEX, match.charIndex)
            startActivity(intent)
        }
        binding.recyclerView.adapter = adapter

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun performSearch(query: String) {
        val results = StoryRepository.searchMatches(this, query)
        adapter.updateData(results, query)
        binding.tvEmpty.visibility =
            if (query.isNotBlank() && results.isEmpty()) View.VISIBLE else View.GONE
    }
}
