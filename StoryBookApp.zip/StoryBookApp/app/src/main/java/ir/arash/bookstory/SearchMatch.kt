package ir.arash.bookstory

/** یک نتیجه‌ی جستجو: هر بار که کلمه در متن یا عنوان پیدا شود، یک نمونه از این کلاس ساخته می‌شود. */
data class SearchMatch(
    val storyId: String,
    val storyTitle: String,
    /** تکه‌ای از متن اطراف کلمه‌ی پیداشده، برای نمایش در لیست نتایج */
    val snippet: String,
    /**
     * موقعیت (index) کاراکتر پیداشده در متن کامل و نرمال‌شده‌ی داستان.
     * اگر منفی ۱ باشد یعنی تطبیق فقط در عنوان داستان بوده، نه در متن.
     */
    val charIndex: Int
)
