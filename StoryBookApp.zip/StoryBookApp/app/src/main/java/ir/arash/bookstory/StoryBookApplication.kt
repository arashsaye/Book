package ir.arash.bookstory

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class StoryBookApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // تم برنامه کاملاً مستقل از تنظیمات گوشی است؛ همیشه بر اساس
        // آخرین انتخاب کاربر در صفحه‌ی تنظیمات اعمال می‌شود (نه حالت گوشی)
        val nightMode = if (SettingsManager.isDarkMode(this)) {
            AppCompatDelegate.MODE_NIGHT_YES
        } else {
            AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }
}
