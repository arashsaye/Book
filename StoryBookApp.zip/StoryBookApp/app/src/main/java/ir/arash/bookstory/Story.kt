package ir.arash.bookstory

data class Story(
    val id: String,
    val title: String,
    val content: String,
    val coverImageName: String? = null // نام فایل drawable (بدون پسوند)، مثلا "cover_story_1"
)
