package ir.arash.bookstory

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import ir.arash.bookstory.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var selectedFontIndex = 0
    private var selectedColorIndex = 0
    private var selectedTextSizeIndex = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolbar.inflateMenu(R.menu.menu_drawer_toggle)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_open_drawer) {
                DrawerController.openDrawer(binding.drawerLayout)
                true
            } else false
        }
        DrawerController.setup(this, binding.drawerLayout)

        selectedFontIndex = SettingsManager.getFontIndex(this)
        selectedColorIndex = SettingsManager.getColorIndex(this)
        selectedTextSizeIndex = SettingsManager.getTextSizeIndex(this)

        // تم تاریک
        binding.switchDarkMode.isChecked = SettingsManager.isDarkMode(this)
        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            SettingsManager.setDarkMode(this, isChecked)
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
            recreate()
        }

        val fontAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.fontNames)
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFont.adapter = fontAdapter
        binding.spinnerFont.setSelection(selectedFontIndex)

        val textSizeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.textSizeNames)
        textSizeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTextSize.adapter = textSizeAdapter
        binding.spinnerTextSize.setSelection(selectedTextSizeIndex)

        val colorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, SettingsManager.colorNames)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerColor.adapter = colorAdapter
        binding.spinnerColor.setSelection(selectedColorIndex)

        updatePreview()

        binding.spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedFontIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerTextSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedTextSizeIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedColorIndex = position
                updatePreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnSave.setOnClickListener {
            SettingsManager.save(this, selectedFontIndex, selectedColorIndex, selectedTextSizeIndex)
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePreview() {
        val typeface = SettingsManager.getTypefaceForIndex(this, selectedFontIndex)
        val colorHex = when (selectedColorIndex) {
            1 -> "#1565C0"
            2 -> "#D32F2F"
            3 -> "#FBC02D"
            4 -> "#FFFFFF"
            else -> "#000000"
        }
        val textSizeSp = when (selectedTextSizeIndex) {
            0 -> 14f
            1 -> 16f
            3 -> 21f
            4 -> 25f
            else -> 18f
        }
        binding.tvPreview.typeface = typeface
        binding.tvPreview.setTextColor(android.graphics.Color.parseColor(colorHex))
        binding.tvPreview.textSize = textSizeSp
    }
}
