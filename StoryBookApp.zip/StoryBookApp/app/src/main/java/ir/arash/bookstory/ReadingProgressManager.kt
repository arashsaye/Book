package ir.arash.bookstory

import android.content.Context

/**
 * آخرین صفحه‌ای که کاربر در هر داستان خوانده را ذخیره می‌کند تا دفعه‌ی بعد
 * که آن داستان باز می‌شود، از همان صفحه شروع شود (نه از صفحه‌ی اول).
 */
object ReadingProgressManager {

    private const val PREFS_NAME = "reading_progress_prefs"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveLastPage(context: Context, storyId: String, pageIndex: Int) {
        prefs(context).edit().putInt(storyId, pageIndex).apply()
    }

    /** اگر صفحه‌ای ذخیره نشده باشد یا نامعتبر باشد، صفر برمی‌گردد. */
    fun getLastPage(context: Context, storyId: String, pageCount: Int): Int {
        val saved = prefs(context).getInt(storyId, 0)
        return if (saved in 0 until pageCount) saved else 0
    }
}
