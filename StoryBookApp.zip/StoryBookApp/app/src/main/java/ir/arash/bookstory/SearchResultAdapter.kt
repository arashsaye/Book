package ir.arash.bookstory

import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ir.arash.bookstory.databinding.ItemSearchResultBinding

class SearchResultAdapter(
    private var matches: List<SearchMatch>,
    private var query: String,
    private val onClick: (SearchMatch) -> Unit
) : RecyclerView.Adapter<SearchResultAdapter.MatchViewHolder>() {

    inner class MatchViewHolder(val binding: ItemSearchResultBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MatchViewHolder {
        val binding = ItemSearchResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MatchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MatchViewHolder, position: Int) {
        val match = matches[position]
        holder.binding.tvTitle.text = match.storyTitle
        holder.binding.tvSnippet.text = highlightQuery(match.snippet, query)
        holder.binding.root.setOnClickListener { onClick(match) }
    }

    override fun getItemCount(): Int = matches.size

    fun updateData(newMatches: List<SearchMatch>, newQuery: String) {
        matches = newMatches
        query = newQuery
        notifyDataSetChanged()
    }

    private fun highlightQuery(snippet: String, query: String): CharSequence {
        val normalizedQuery = TextNormalizer.normalize(query.trim())
        if (normalizedQuery.isEmpty()) return snippet

        val spannable = SpannableString(snippet)
        var from = 0
        while (true) {
            val idx = snippet.indexOf(normalizedQuery, from, ignoreCase = true)
            if (idx == -1) break
            val end = idx + normalizedQuery.length
            spannable.setSpan(StyleSpan(android.graphics.Typeface.BOLD), idx, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannable.setSpan(BackgroundColorSpan(0x66C9A15A), idx, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            from = end
        }
        return spannable
    }
}
