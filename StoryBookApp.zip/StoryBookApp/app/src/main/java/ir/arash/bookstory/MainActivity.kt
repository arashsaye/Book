package ir.arash.bookstory

import android.content.Intent
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import ir.arash.bookstory.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnList.setOnClickListener {
            startActivity(Intent(this, StoryListActivity::class.java))
        }
        binding.btnSearch.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }
        binding.btnFavorites.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
        binding.btnExit.setOnClickListener {
            DrawerController.confirmExit(this)
        }

        binding.toolbarMain.setNavigationOnClickListener {
            DrawerController.openDrawer(binding.drawerLayout)
        }
        DrawerController.setup(this, binding.drawerLayout)

        // دکمه یا حرکت برگشت (چه فیزیکی چه ژست‌های اندروید جدید) هم باید همین دیالوگ تایید خروج را نشان دهد
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(androidx.core.view.GravityCompat.START)) {
                    binding.drawerLayout.closeDrawers()
                } else {
                    DrawerController.confirmExit(this@MainActivity)
                }
            }
        })
    }
}

