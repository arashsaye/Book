package ir.arash.bookstory

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import ir.arash.bookstory.databinding.ActivityAboutBinding
import android.content.Intent
import android.net.Uri

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolbar.inflateMenu(R.menu.menu_drawer_toggle)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_open_drawer) {
                DrawerController.openDrawer(binding.drawerLayout)
                true
            } else false
        }
        DrawerController.setup(this, binding.drawerLayout)
        binding.rowInstagram.setOnClickListener {
    openLink("https://www.instagram.com/nevisande.vorojak2?igsh=MWttcjNsZWV2czYyeg==")
}
binding.rowWhatsapp.setOnClickListener {
    openLink("https://whatsapp.com/channel/0029Vb1s1FsBqbrFW0FenO2L")
}
binding.rowTelegram.setOnClickListener {
    openLink("https://t.me/Sooetafahomha")
}
    }
    private fun openLink(url: String) {
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
}
