package ir.arash.bookstory

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import ir.arash.bookstory.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolbar.inflateMenu(R.menu.menu_drawer_toggle)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_open_drawer) {
                DrawerController.openDrawer(binding.drawerLayout)
                true
            } else false
        }
        DrawerController.setup(this, binding.drawerLayout)
    }
}
