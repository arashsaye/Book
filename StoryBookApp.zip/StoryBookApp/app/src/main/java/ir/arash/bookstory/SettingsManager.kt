package ir.arash.bookstory

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface

object SettingsManager {

    private const val PREFS_NAME = "settings_prefs"
    private const val KEY_FONT_INDEX = "font_index"
    private const val KEY_COLOR_INDEX = "color_index"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_TEXT_SIZE_INDEX = "text_size_index"

    // نام فونت‌ها (فونت‌های داخلی اندروید که بدون فایل اضافه کار می‌کنند)
    // برای افزودن فونت فارسی اختصاصی (مثلا وزیر یا ایران‌سنس)،
    // فایل .ttf را در res/font قرار دهید و در اینجا با ResourcesCompat.getFont ارجاع دهید.
    val fontNames = listOf("پیش‌فرض", "نازنین (Nazanin)", "کودک (koodak)","الهام (elham)", "حمید (hamid)","مروارید (Morvarid)", "تیر (Tir)")

    fun getTypeface(context: Context): Typeface {
        return when (getFontIndex(context)) {
            1 -> ResourcesCompat.getFont(context, R.font.bnazanin)!!
            2 -> ResourcesCompat.getFont(context, R.font.bkoodak)!!
            3 -> ResourcesCompat.getFont(context, R.font.belham)!!
            4 -> ResourcesCompat.getFont(context, R.font.bhamid)!!
            5 -> ResourcesCompat.getFont(context, R.font.bmorvarid)!!
            6 -> ResourcesCompat.getFont(context, R.font.btir)!!
            else -> Typeface.DEFAULT
        }
    }


    // رنگ‌های درخواستی کاربر (سیاه اول، سفید آخر)
    val colorNames = listOf("مشکی", "آبی", "قرمز", "زرد", "سفید")

    private val colorValues = listOf(
        Color.parseColor("#000000"),
        Color.parseColor("#1565C0"),
        Color.parseColor("#D32F2F"),
        Color.parseColor("#FBC02D"),
        Color.parseColor("#FFFFFF")
    )

    // اندازه‌ی متن داستان (بر حسب sp)
    val textSizeNames = listOf("خیلی کوچک", "کوچک", "متوسط", "بزرگ", "خیلی بزرگ")
    private val textSizeValues = listOf(14f, 16f, 18f, 21f, 25f)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getFontIndex(context: Context): Int = prefs(context).getInt(KEY_FONT_INDEX, 0)
    fun getColorIndex(context: Context): Int = prefs(context).getInt(KEY_COLOR_INDEX, 0)
    fun getTextSizeIndex(context: Context): Int = prefs(context).getInt(KEY_TEXT_SIZE_INDEX, 2)

    fun getTypeface(context: Context): Typeface = typefaces[getFontIndex(context)]
    fun getTextColor(context: Context): Int = colorValues[getColorIndex(context)]
    fun getTextSizeSp(context: Context): Float = textSizeValues[getTextSizeIndex(context)]

    fun isDarkMode(context: Context): Boolean = prefs(context).getBoolean(KEY_DARK_MODE, false)

    fun setDarkMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    fun save(context: Context, fontIndex: Int, colorIndex: Int, textSizeIndex: Int) {
        prefs(context).edit()
            .putInt(KEY_FONT_INDEX, fontIndex)
            .putInt(KEY_COLOR_INDEX, colorIndex)
            .putInt(KEY_TEXT_SIZE_INDEX, textSizeIndex)
            .apply()
    }
}
