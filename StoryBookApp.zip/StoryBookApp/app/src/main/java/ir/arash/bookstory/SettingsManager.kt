package ir.arash.bookstory

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

object SettingsManager {

    private const val PREFS_NAME = "settings_prefs"
    private const val KEY_FONT_INDEX = "font_index"
    private const val KEY_COLOR_INDEX = "color_index"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_TEXT_SIZE_INDEX = "text_size_index"

    // نام فونت‌ها. فونت اول همیشه پیش‌فرض سیستم است.
    // برای افزودن فونت جدید: فایل .ttf را با اسمی فقط شامل حروف کوچک انگلیسی
    // و بدون فاصله در res/font قرار دهید، یک اسم به fontNames اضافه کنید و
    // یک case جدید در getTypeface() برای آن اضافه کنید.
    val fontNames = listOf("پیش‌فرض", "نازنین (Nazanin)")

    fun getTypeface(context: Context): Typeface {
        return when (getFontIndex(context)) {
            1 -> ResourcesCompat.getFont(context, R.font.bnazanin)!!
            else -> Typeface.DEFAULT
        }
    }

    // رنگ‌های درخواستی کاربر (سیاه اول، سفید آخر)
    val colorNames = listOf("مشکی", "آبی", "قرمز", "زرد", "سفید")

    private val colorValues = listOf(
        Color.parseColor("#000000"),
        Color.parseColor("#1565C0"),
        Color.parseColor("#D32F2F"),
        Color.parseColor("#FBC02D"),
        Color.parseColor("#FFFFFF")
    )

    // اندازه‌ی متن داستان (بر حسب sp)
    val textSizeNames = listOf("خیلی کوچک", "کوچک", "متوسط", "بزرگ", "خیلی بزرگ")
    private val textSizeValues = listOf(14f, 16f, 18f, 21f, 25f)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getFontIndex(context: Context): Int {
        val saved = prefs(context).getInt(KEY_FONT_INDEX, 0)
        // اگر عددی که قبلاً ذخیره شده با فهرست فعلی فونت‌ها جور نباشد (مثلاً بعد از حذف فونت‌های قدیمی)، به پیش‌فرض برگرد
        return if (saved in fontNames.indices) saved else 0
    }

    fun getColorIndex(context: Context): Int = prefs(context).getInt(KEY_COLOR_INDEX, 0)
    fun getTextSizeIndex(context: Context): Int = prefs(context).getInt(KEY_TEXT_SIZE_INDEX, 2)

    fun getTextColor(context: Context): Int = colorValues[getColorIndex(context)]
    fun getTextSizeSp(context: Context): Float = textSizeValues[getTextSizeIndex(context)]

    fun isDarkMode(context: Context): Boolean = prefs(context).getBoolean(KEY_DARK_MODE, false)

    fun setDarkMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    fun save(context: Context, fontIndex: Int, colorIndex: Int, textSizeIndex: Int) {
        prefs(context).edit()
            .putInt(KEY_FONT_INDEX, fontIndex)
            .putInt(KEY_COLOR_INDEX, colorIndex)
            .putInt(KEY_TEXT_SIZE_INDEX, textSizeIndex)
            .apply()
    }
}

