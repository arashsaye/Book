package ir.arash.bookstory

/**
 * متن داستان را بر اساس تعداد تقریبی کاراکتر به صفحات مجزا تقسیم می‌کند،
 * و تلاش می‌کند شکستن صفحه در وسط یک پاراگراف رخ ندهد.
 */
object PagingUtil {

    private const val CHARS_PER_PAGE = 900

    fun splitIntoPages(content: String): List<String> {
        val paragraphs = content.split("\n\n")
        val pages = mutableListOf<String>()
        val current = StringBuilder()

        for (paragraph in paragraphs) {
            if (current.length + paragraph.length > CHARS_PER_PAGE && current.isNotEmpty()) {
                pages.add(current.toString().trim())
                current.clear()
            }
            current.append(paragraph).append("\n\n")
        }
        if (current.isNotBlank()) {
            pages.add(current.toString().trim())
        }
        return if (pages.isEmpty()) listOf(content) else pages
    }
}
