package ir.arash.bookstory

/**
 * متن داستان را بر اساس تعداد تقریبی کاراکتر به صفحات مجزا تقسیم می‌کند،
 * و تلاش می‌کند شکستن صفحه در وسط یک پاراگراف رخ ندهد.
 */
object PagingUtil {

    private const val CHARS_PER_PAGE = 1500

    /** یک صفحه به همراه موقعیت شروعش (بر حسب کاراکتر) در متن کامل و نرمال‌شده‌ی داستان. */
    data class Page(val text: String, val startOffset: Int)

    fun splitIntoPages(content: String): List<String> = splitWithOffsets(content).map { it.text }

    /**
     * مثل splitIntoPages، ولی علاوه بر متن هر صفحه، موقعیت شروع آن صفحه در متن
     * کامل را هم برمی‌گرداند. این برای این لازم است که وقتی جستجو کلمه‌ای را در
     * جایی از متن پیدا می‌کند، بشود فهمید آن جا دقیقاً در کدام صفحه قرار دارد.
     */
    fun splitWithOffsets(content: String): List<Page> {
        // خط‌شکن‌های ویندوزی (\r\n) و مکینتاش قدیمی (\r) را به \n یکسان‌سازی می‌کنیم
        // تا فرقی نکند فایل txt با چه ویرایشگری ذخیره شده باشد.
        val normalized = content.replace("\r\n", "\n").replace("\r", "\n")

        // بر اساس خط (نه لزوماً خط خالی) پاراگراف‌بندی می‌کنیم، چون بعضی فایل‌های
        // متنی بین پاراگراف‌ها خط خالی ندارند و فقط هر پاراگراف روی خط خودش است.
        // این‌طوری هیچ‌وقت وسط یک خط/پاراگراف صفحه شکسته نمی‌شود.
        val lines = normalized.split("\n")
        val pages = mutableListOf<Page>()
        val current = StringBuilder()
        var cursor = 0
        var pageStart = 0

        for (line in lines) {
            if (current.length + line.length > CHARS_PER_PAGE && current.isNotEmpty()) {
                pages.add(Page(current.toString().trim(), pageStart))
                current.clear()
                pageStart = cursor
            }
            current.append(line).append("\n")
            cursor += line.length + 1
        }
        if (current.isNotBlank()) {
            pages.add(Page(current.toString().trim(), pageStart))
        }
        return if (pages.isEmpty()) listOf(Page(normalized, 0)) else pages
    }

    /** شماره‌ی صفحه‌ای را برمی‌گرداند که یک موقعیت مشخص از متن کامل در آن قرار دارد. */
    fun pageIndexForOffset(pages: List<Page>, charOffset: Int): Int {
        for (i in pages.indices.reversed()) {
            if (charOffset >= pages[i].startOffset) return i
        }
        return 0
    }
}
