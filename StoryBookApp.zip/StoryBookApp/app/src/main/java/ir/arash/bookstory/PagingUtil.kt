package ir.arash.bookstory

/**
 * متن داستان را بر اساس تعداد تقریبی کاراکتر به صفحات مجزا تقسیم می‌کند،
 * و تلاش می‌کند شکستن صفحه در وسط یک پاراگراف رخ ندهد.
 */
object PagingUtil {

    private const val CHARS_PER_PAGE = 6000

    fun splitIntoPages(content: String): List<String> {
        // خط‌شکن‌های ویندوزی (\r\n) و مکینتاش قدیمی (\r) را به \n یکسان‌سازی می‌کنیم
        // تا فرقی نکند فایل txt با چه ویرایشگری ذخیره شده باشد.
        val normalized = content.replace("\r\n", "\n").replace("\r", "\n")

        // بر اساس خط (نه لزوماً خط خالی) پاراگراف‌بندی می‌کنیم، چون بعضی فایل‌های
        // متنی بین پاراگراف‌ها خط خالی ندارند و فقط هر پاراگراف روی خط خودش است.
        // این‌طوری هیچ‌وقت وسط یک خط/پاراگراف صفحه شکسته نمی‌شود.
        val lines = normalized.split("\n")
        val pages = mutableListOf<String>()
        val current = StringBuilder()

        for (line in lines) {
            if (current.length + line.length > CHARS_PER_PAGE && current.isNotEmpty()) {
                pages.add(current.toString().trim())
                current.clear()
            }
            current.append(line).append("\n")
        }
        if (current.isNotBlank()) {
            pages.add(current.toString().trim())
        }
        return if (pages.isEmpty()) listOf(normalized) else pages
    }
}
