package ir.arash.bookstory

import android.content.Context
import org.json.JSONArray

/**
 * داستان‌ها از فایل assets/stories.json خوانده می‌شوند.
 *
 * برای افزودن داستان جدید (روش پیشنهادی، برای متن‌های طولانی):
 * ۱. متن کامل داستان را همان‌طور که هست (با خط خالی بین پاراگراف‌ها) در یک
 *    فایل متنی ساده با پسوند .txt در پوشه‌ی assets/stories/ ذخیره کنید،
 *    مثلا assets/stories/4.txt — نیازی به تبدیل خط‌ها به \n یا یک‌خطی کردن نیست.
 * ۲. یک آبجکت جدید با فیلدهای id, title, file (نام همان فایل txt) و در
 *    صورت تمایل cover به آرایه‌ی JSON در stories.json اضافه کنید.
 *
 * (فرمت قدیمی‌تر که متن مستقیم داخل فیلد "content" در stories.json نوشته
 * می‌شد هم همچنان پشتیبانی می‌شود، اما برای داستان‌های طولانی توصیه نمی‌شود
 * چون باید همه‌ی خط‌های متن به‌صورت \n در یک رشته‌ی جیسون جا بگیرند.)
 */
object StoryRepository {

    private var cache: List<Story>? = null

    fun getAllStories(context: Context): List<Story> {
        cache?.let { return it }

        val jsonText = context.assets.open("stories.json")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        val jsonArray = JSONArray(jsonText)
        val list = mutableListOf<Story>()
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            val content = when {
                obj.has("file") -> context.assets
                    .open("stories/${obj.getString("file")}")
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                obj.has("content") -> obj.getString("content")
                else -> ""
            }
            list.add(
                Story(
                    id = obj.getString("id"),
                    title = TextNormalizer.normalize(obj.getString("title")),
                    content = TextNormalizer.normalize(content),
                    coverImageName = if (obj.has("cover")) obj.getString("cover") else null
                )
            )
        }
        cache = list
        return list
    }

    fun getStoryById(context: Context, id: String): Story? {
        return getAllStories(context).firstOrNull { it.id == id }
    }

    fun search(context: Context, query: String): List<Story> {
        if (query.isBlank()) return emptyList()
        val q = TextNormalizer.normalize(query.trim())
        return getAllStories(context).filter {
            it.title.contains(q, ignoreCase = true) || it.content.contains(q, ignoreCase = true)
        }
    }

    private const val SNIPPET_CONTEXT_CHARS = 28

    /**
     * برخلاف search()، برای هر بار که کلمه در یک داستان تکرار شده یک نتیجه‌ی
     * جداگانه برمی‌گرداند (نه فقط یک نتیجه به‌ازای هر داستان).
     */
    fun searchMatches(context: Context, query: String): List<SearchMatch> {
        if (query.isBlank()) return emptyList()
        val q = TextNormalizer.normalize(query.trim())
        if (q.isEmpty()) return emptyList()

        val results = mutableListOf<SearchMatch>()
        for (story in getAllStories(context)) {
            if (story.title.contains(q, ignoreCase = true)) {
                results.add(SearchMatch(story.id, story.title, story.title, charIndex = -1))
            }

            var fromIndex = 0
            val content = story.content
            while (true) {
                val idx = content.indexOf(q, fromIndex, ignoreCase = true)
                if (idx == -1) break
                val start = (idx - SNIPPET_CONTEXT_CHARS).coerceAtLeast(0)
                val end = (idx + q.length + SNIPPET_CONTEXT_CHARS).coerceAtMost(content.length)
                val snippet = buildString {
                    if (start > 0) append("…")
                    append(content.substring(start, end).replace('\n', ' '))
                    if (end < content.length) append("…")
                }
                results.add(SearchMatch(story.id, story.title, snippet, idx))
                fromIndex = idx + q.length
            }
        }
        return results
    }
}
