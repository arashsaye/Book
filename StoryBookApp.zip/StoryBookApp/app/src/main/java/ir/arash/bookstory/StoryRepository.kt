package ir.arash.bookstory

import android.content.Context
import org.json.JSONArray

/**
 * داستان‌ها از فایل assets/stories.json خوانده می‌شوند.
 * برای افزودن داستان جدید، کافیست یک آبجکت جدید با فیلدهای
 * id, title, content به آرایه‌ی JSON اضافه کنید.
 */
object StoryRepository {

    private var cache: List<Story>? = null

    fun getAllStories(context: Context): List<Story> {
        cache?.let { return it }

        val jsonText = context.assets.open("stories.json")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        val jsonArray = JSONArray(jsonText)
        val list = mutableListOf<Story>()
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            list.add(
                Story(
                    id = obj.getString("id"),
                    title = obj.getString("title"),
                    content = obj.getString("content"),
                    coverImageName = if (obj.has("cover")) obj.getString("cover") else null
                )
            )
        }
        cache = list
        return list
    }

    fun getStoryById(context: Context, id: String): Story? {
        return getAllStories(context).firstOrNull { it.id == id }
    }

    fun search(context: Context, query: String): List<Story> {
        if (query.isBlank()) return emptyList()
        val q = query.trim()
        return getAllStories(context).filter {
            it.title.contains(q, ignoreCase = true) || it.content.contains(q, ignoreCase = true)
        }
    }
}
