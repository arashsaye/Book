package ir.arash.bookstory

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import ir.arash.bookstory.databinding.ActivityStoryReaderBinding

class StoryReaderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STORY_ID = "extra_story_id"
        const val EXTRA_SEARCH_QUERY = "extra_search_query"
        const val EXTRA_MATCH_CHAR_INDEX = "extra_match_char_index"
    }

    private lateinit var binding: ActivityStoryReaderBinding
    private lateinit var story: Story
    private lateinit var pages: List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val storyId = intent.getStringExtra(EXTRA_STORY_ID)
        val loadedStory = storyId?.let { StoryRepository.getStoryById(this, it) }

        if (loadedStory == null) {
            finish()
            return
        }
        story = loadedStory
        val pagesWithOffsets = PagingUtil.splitWithOffsets(story.content)
        pages = pagesWithOffsets.map { it.text }

        binding.toolbar.title = story.title
        binding.toolbar.setTitleTextColor(0xFFFFFFFF.toInt())
        binding.toolbar.setNavigationOnClickListener {
            DrawerController.openDrawer(binding.drawerLayout)
        }

        binding.toolbar.inflateMenu(R.menu.menu_reader)
        val favoriteMenuItem = binding.toolbar.menu.findItem(R.id.action_favorite)

        fun updateFavoriteIcon() {
            val isFav = FavoritesManager.isFavorite(this, story.id)
            favoriteMenuItem.setIcon(
                if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )
        }
        updateFavoriteIcon()

        DrawerController.setup(this, binding.drawerLayout)

        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_favorite) {
                FavoritesManager.toggleFavorite(this, story.id)
                updateFavoriteIcon()
                // طبق نیاز پروژه: انتخاب علامت علاقه‌مندی کاربر را به صفحه‌ی علاقه‌مندی‌ها می‌برد
                startActivity(Intent(this, FavoritesActivity::class.java))
                true
            } else {
                false
            }
        }

        // اگر از صفحه‌ی جستجو باز شده باشیم، دقیقاً همان صفحه و همان خطی که کلمه در آن است باز می‌شود
        // و آن کلمه هایلایت می‌شود. در غیر این صورت از آخرین صفحه‌ای که قبلاً در این داستان بودیم شروع می‌شود.
        val searchQuery = intent.getStringExtra(EXTRA_SEARCH_QUERY)
        val matchCharIndex = intent.getIntExtra(EXTRA_MATCH_CHAR_INDEX, -1)

        var highlightPageIndex = -1
        var highlightStart = -1
        var highlightEnd = -1

        val initialPage = if (matchCharIndex >= 0) {
            val pageIndex = PagingUtil.pageIndexForOffset(pagesWithOffsets, matchCharIndex)
            val page = pagesWithOffsets[pageIndex]
            val normalizedQuery = TextNormalizer.normalize(searchQuery.orEmpty().trim())
            if (normalizedQuery.isNotEmpty()) {
                // موقعیت تقریبی داخل همین صفحه را به‌عنوان نقطه‌ی شروع جستجو استفاده می‌کنیم
                // تا اگر کلمه چند بار در همین صفحه تکرار شده، دقیقاً همان‌جایی که کاربر رویش
                // کلیک کرده هایلایت شود، نه لزوماً اولین‌بار در کل صفحه.
                val approx = (matchCharIndex - page.startOffset).coerceIn(0, page.text.length)
                val searchFrom = (approx - 30).coerceAtLeast(0)
                var foundIdx = page.text.indexOf(normalizedQuery, searchFrom, ignoreCase = true)
                if (foundIdx == -1) {
                    foundIdx = page.text.indexOf(normalizedQuery, ignoreCase = true)
                }
                if (foundIdx >= 0) {
                    highlightPageIndex = pageIndex
                    highlightStart = foundIdx
                    highlightEnd = foundIdx + normalizedQuery.length
                }
            }
            pageIndex
        } else if (!searchQuery.isNullOrBlank()) {
            val matchedPage = pages.indexOfFirst {
                it.contains(TextNormalizer.normalize(searchQuery.trim()), ignoreCase = true)
            }
            if (matchedPage >= 0) matchedPage else 0
        } else {
            ReadingProgressManager.getLastPage(this, story.id, pages.size)
        }

        binding.viewPager.adapter = StoryPagerAdapter(
            this, pages, story.coverImageName, highlightPageIndex, highlightStart, highlightEnd
        )

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageIndicator(position)
                ReadingProgressManager.saveLastPage(this@StoryReaderActivity, story.id, position)
            }
        })

        binding.viewPager.setCurrentItem(initialPage, false)
        updatePageIndicator(initialPage)

        binding.btnGoToPage.setOnClickListener {
            showGoToPageDialog()
        }

        binding.btnPrevPage.setOnClickListener {
            if (binding.viewPager.currentItem > 0) {
                binding.viewPager.currentItem -= 1
            }
        }
        binding.btnNextPage.setOnClickListener {
            if (binding.viewPager.currentItem < pages.size - 1) {
                binding.viewPager.currentItem += 1
            }
        }
    }

    private fun showGoToPageDialog() {
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.go_to_page_hint, pages.size)
            setText((binding.viewPager.currentItem + 1).toString())
            setSelection(text.length)
            gravity = android.view.Gravity.CENTER
        }
        val container = android.widget.FrameLayout(this).apply {
            val paddingPx = (24 * resources.displayMetrics.density).toInt()
            setPadding(paddingPx, paddingPx / 2, paddingPx, 0)
            addView(input)
        }

        val dialog = androidx.appcompat.app.AlertDialog.Builder(this, R.style.AppAlertDialogTheme)
            .setTitle(R.string.go_to_page_title)
            .setView(container)
            .setPositiveButton(R.string.go, null)
            .setNegativeButton(R.string.cancel, null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pageNumber = input.text.toString().toIntOrNull()
                if (pageNumber == null || pageNumber < 1 || pageNumber > pages.size) {
                    input.error = getString(R.string.go_to_page_invalid)
                } else {
                    binding.viewPager.setCurrentItem(pageNumber - 1, false)
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    override fun onPause() {
        super.onPause()
        if (::story.isInitialized) {
            ReadingProgressManager.saveLastPage(this, story.id, binding.viewPager.currentItem)
        }
    }

    private fun updatePageIndicator(position: Int) {
        binding.tvPageIndicator.text =
            getString(R.string.page_indicator, position + 1, pages.size)
        binding.btnPrevPage.isEnabled = position > 0
        binding.btnNextPage.isEnabled = position < pages.size - 1
    }
}
