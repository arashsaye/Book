package ir.arash.bookstory

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import ir.arash.bookstory.databinding.ActivityStoryReaderBinding

class StoryReaderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STORY_ID = "extra_story_id"
        const val EXTRA_SEARCH_QUERY = "extra_search_query"
    }

    private lateinit var binding: ActivityStoryReaderBinding
    private lateinit var story: Story
    private lateinit var pages: List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val storyId = intent.getStringExtra(EXTRA_STORY_ID)
        val loadedStory = storyId?.let { StoryRepository.getStoryById(this, it) }

        if (loadedStory == null) {
            finish()
            return
        }
        story = loadedStory
        pages = PagingUtil.splitIntoPages(story.content)

        binding.toolbar.title = story.title
        binding.toolbar.setTitleTextColor(0xFFFFFFFF.toInt())
        binding.toolbar.setNavigationOnClickListener {
            DrawerController.openDrawer(binding.drawerLayout)
        }

        binding.toolbar.inflateMenu(R.menu.menu_reader)
        val favoriteMenuItem = binding.toolbar.menu.findItem(R.id.action_favorite)

        fun updateFavoriteIcon() {
            val isFav = FavoritesManager.isFavorite(this, story.id)
            favoriteMenuItem.setIcon(
                if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )
        }
        updateFavoriteIcon()

        DrawerController.setup(this, binding.drawerLayout)

        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_favorite) {
                FavoritesManager.toggleFavorite(this, story.id)
                updateFavoriteIcon()
                // طبق نیاز پروژه: انتخاب علامت علاقه‌مندی کاربر را به صفحه‌ی علاقه‌مندی‌ها می‌برد
                startActivity(Intent(this, FavoritesActivity::class.java))
                true
            } else {
                false
            }
        }

        binding.viewPager.adapter = StoryPagerAdapter(this, pages, story.coverImageName)

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageIndicator(position)
            }
        })

        // اگر از صفحه‌ی جستجو باز شده باشیم، مستقیم به صفحه‌ای برو که کلمه‌ی جستجوشده در آن است
        val searchQuery = intent.getStringExtra(EXTRA_SEARCH_QUERY)
        val initialPage = if (!searchQuery.isNullOrBlank()) {
            val matchedPage = pages.indexOfFirst { it.contains(searchQuery, ignoreCase = true) }
            if (matchedPage >= 0) matchedPage else 0
        } else {
            0
        }
        binding.viewPager.setCurrentItem(initialPage, false)
        updatePageIndicator(initialPage)

        binding.btnPrevPage.setOnClickListener {
            if (binding.viewPager.currentItem > 0) {
                binding.viewPager.currentItem -= 1
            }
        }
        binding.btnNextPage.setOnClickListener {
            if (binding.viewPager.currentItem < pages.size - 1) {
                binding.viewPager.currentItem += 1
            }
        }
    }

    private fun updatePageIndicator(position: Int) {
        binding.tvPageIndicator.text =
            getString(R.string.page_indicator, position + 1, pages.size)
        binding.btnPrevPage.isEnabled = position > 0
        binding.btnNextPage.isEnabled = position < pages.size - 1
    }
}
